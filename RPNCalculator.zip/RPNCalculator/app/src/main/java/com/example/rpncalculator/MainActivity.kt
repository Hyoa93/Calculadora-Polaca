package com.example.rpncalculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rpncalculator.ui.theme.RPNCalculatorTheme
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RPNCalculatorTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    RPNCalculatorApp()
                }
            }
        }
    }
}

// Clase para manejar la lógica RPN
class RPNEngine {
    private val stack = Stack<Double>()
    private var currentInput = StringBuilder()
    private var waitingForOperand = false

    fun getStack(): List<Double> = stack.reversed()
    fun getCurrentInput(): String = currentInput.toString()
    fun getTopValue(): Double = if (stack.isNotEmpty()) stack.peek() else 0.0

    fun appendNumber(value: String) {
        if (waitingForOperand) {
            currentInput.clear()
            waitingForOperand = false
        }
        if (value == "." && currentInput.contains(".")) return
        currentInput.append(value)
    }

    fun pushCurrentNumber(): String {
        if (currentInput.isNotEmpty()) {
            val number = currentInput.toString().toDoubleOrNull()
            if (number != null) {
                stack.push(number)
                currentInput.clear()
                waitingForOperand = false
                return formatResult(number)
            }
            return "Error"
        } else if (stack.isNotEmpty()) {
            stack.push(stack.peek())
            return formatResult(stack.peek())
        }
        return "0"
    }

    fun executeOperation(operation: String): String {
        if (stack.size >= 2) {
            val a = stack.pop()
            val b = stack.pop()
            val result = when (operation) {
                "+" -> b + a
                "-" -> b - a
                "×" -> b * a
                "÷" -> if (a != 0.0) b / a else Double.NaN
                else -> Double.NaN
            }

            if (result.isNaN() || result.isInfinite()) {
                clearAll()
                return "Error"
            }
            stack.push(result)
            waitingForOperand = true
            return formatResult(result)
        }
        return "Error: faltan operandos"
    }

    fun swapTop(): String {
        if (stack.size >= 2) {
            val a = stack.pop()
            val b = stack.pop()
            stack.push(a)
            stack.push(b)
            return formatResult(stack.peek())
        }
        return "Error: se necesitan 2 elementos"
    }

    fun dropTop(): String {
        if (stack.isNotEmpty()) {
            stack.pop()
            return if (stack.isNotEmpty()) formatResult(stack.peek()) else "0"
        }
        return "Error: stack vacío"
    }

    fun clearAll() {
        stack.clear()
        currentInput.clear()
        waitingForOperand = false
    }

    fun clearEntry() {
        currentInput.clear()
        waitingForOperand = false
    }

    private fun formatResult(value: Double): String {
        return if (value == value.toLong().toDouble()) {
            value.toLong().toString()
        } else {
            "%.8f".format(value).trimEnd('0').trimEnd('.')
        }
    }
}

@Composable
fun RPNCalculatorApp() {
    val engine = remember { RPNEngine() }
    var displayValue by remember { mutableStateOf("0") }
    var expressionValue by remember { mutableStateOf("") }
    var stackValue by remember { mutableStateOf(listOf<Double>()) }

    fun updateDisplay() {
        val current = engine.getCurrentInput()
        displayValue = if (current.isNotEmpty()) current else {
            if (engine.getStack().isNotEmpty()) engine.getTopValue().let {
                if (it == it.toLong().toDouble()) it.toLong().toString() else "%.8f".format(it).trimEnd('0').trimEnd('.')
            } else "0"
        }
        stackValue = engine.getStack()
        expressionValue = current
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E1E2E))
            .padding(16.dp)
    ) {
        // Display del stack
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF2A2A3E))
        ) {
            Text(
                text = "Stack (top → bottom): ${stackValue.joinToString(" ") {
                    if (it == it.toLong().toDouble()) it.toLong().toString() else "%.6f".format(it).trimEnd('0').trimEnd('.')
                }}",
                modifier = Modifier.padding(12.dp),
                color = Color(0xFFB0B0B0),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Display de expresión
        Text(
            text = expressionValue,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.End,
            color = Color(0xFFB0B0B0),
            fontSize = 18.sp,
            fontFamily = FontFamily.Monospace
        )

        // Display principal
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF2A2A3E))
        ) {
            Text(
                text = displayValue,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                textAlign = TextAlign.End,
                color = Color.White,
                fontSize = 48.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Botones
        val buttons = listOf(
            listOf("7", "8", "9", "÷"),
            listOf("4", "5", "6", "×"),
            listOf("1", "2", "3", "-"),
            listOf("0", ".", "ENTER", "+"),
            listOf("C", "CE", "SWAP", "DROP")
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(buttons.flatten()) { label ->
                Button(
                    onClick = {
                        when (label) {
                            "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "." -> {
                                engine.appendNumber(label)
                                updateDisplay()
                            }
                            "ENTER" -> {
                                val result = engine.pushCurrentNumber()
                                updateDisplay()
                            }
                            "+", "-", "×", "÷" -> {
                                val result = engine.executeOperation(label)
                                updateDisplay()
                            }
                            "SWAP" -> {
                                val result = engine.swapTop()
                                updateDisplay()
                            }
                            "DROP" -> {
                                val result = engine.dropTop()
                                updateDisplay()
                            }
                            "C" -> {
                                engine.clearAll()
                                updateDisplay()
                            }
                            "CE" -> {
                                engine.clearEntry()
                                updateDisplay()
                            }
                        }
                    },
                    modifier = Modifier
                        .height(70.dp)
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = when (label) {
                            "C", "CE" -> Color(0xFF3A2A2A)
                            "ENTER" -> Color(0xFF2E7D32)
                            "SWAP", "DROP" -> Color(0xFF1A3A5C)
                            in listOf("+", "-", "×", "÷") -> Color(0xFF3A2A1A)
                            else -> Color(0xFF3A3A4E)
                        }
                    )
                ) {
                    Text(
                        text = label,
                        fontSize = when (label) {
                            "ENTER", "SWAP", "DROP" -> 14.sp
                            else -> 24.sp
                        },
                        color = when (label) {
                            "C", "CE" -> Color(0xFFFF8A80)
                            "ENTER" -> Color.White
                            "SWAP", "DROP" -> Color(0xFF81D4FA)
                            in listOf("+", "-", "×", "÷") -> Color(0xFFFFD966)
                            else -> Color.White
                        },
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}